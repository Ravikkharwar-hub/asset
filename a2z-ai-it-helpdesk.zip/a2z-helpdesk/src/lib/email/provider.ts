export interface EmailProvider { send(to: string, subject: string, html: string): Promise<void>; }
const resend: EmailProvider = { async send(to, subject, html) {
  const r = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({ from: process.env.EMAIL_FROM, to, subject, html }) });
  if (!r.ok) throw new Error(`Email error ${r.status}`); } };
export const email: EmailProvider = resend;
