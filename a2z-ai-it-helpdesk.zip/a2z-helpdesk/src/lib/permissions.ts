import { supabaseServer } from "@/lib/supabase/server";
export type Resource = "tickets" | "assets" | "kb_articles" | "automation_rules" | "roles" | "users" | "ai" | "integrations" | "audit";
export type Action = "create" | "read" | "update" | "delete" | "export" | "approve" | "assign" | "configure" | "manage";
/** Permissions live in the DB (role_permissions); this calls the same has_perm() used by RLS. */
export async function can(resource: Resource, action: Action) {
  const sb = await supabaseServer();
  const { data } = await sb.rpc("has_perm", { r: resource, a: action });
  return data === true;
}
export async function audit(action: string, entity: string, entityId: string, meta: object = {}) {
  const { headers } = await import("next/headers"); const h = await headers(); const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  const { data: org } = await sb.rpc("current_org");
  await sb.from("audit_logs").insert({ org_id: org, actor_id: user?.id, action, entity, entity_id: entityId,
    ip: h.get("x-forwarded-for"), user_agent: h.get("user-agent"), meta });
}
