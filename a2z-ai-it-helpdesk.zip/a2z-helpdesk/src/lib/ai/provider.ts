export interface TicketAnalysis { category: string; priority: "low"|"medium"|"high"|"critical"; summary: string; sentiment: string; troubleshooting: string[]; suggestedReply: string; suggestedSlaHours: number; }
export interface AIProvider { analyzeTicket(subject: string, description: string, kb: string[]): Promise<TicketAnalysis>; }
const PROMPT = (s: string, d: string, kb: string[]) => `You are an IT helpdesk triage assistant. Return ONLY JSON with keys category, priority(low|medium|high|critical), summary, sentiment, troubleshooting(string[]), suggestedReply, suggestedSlaHours(number).\nKnowledge base:\n${kb.join("\n---\n")}\n\nTicket: ${s}\n${d}`;
const anthropic: AIProvider = { async analyzeTicket(s, d, kb) {
  const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "x-api-key": process.env.ANTHROPIC_API_KEY!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model: process.env.AI_MODEL ?? "claude-sonnet-4-6", max_tokens: 1000, messages: [{ role: "user", content: PROMPT(s, d, kb) }] }) });
  if (!r.ok) throw new Error(`AI error ${r.status}`);
  return JSON.parse(((await r.json()).content[0].text as string).replace(/```json|```/g, "")); } };
export function getAI(): AIProvider {
  if ((process.env.AI_PROVIDER ?? "anthropic") === "anthropic") return anthropic;
  throw new Error("Add another provider here by implementing AIProvider");
}
// AI output is stored in tickets.ai_suggestion and only applied after a human sets ai_reviewed_by.
