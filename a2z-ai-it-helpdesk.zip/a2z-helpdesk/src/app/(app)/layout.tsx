import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";
const nav = ["Dashboard","Tickets","My Tickets","Knowledge Base","Reports","Automation","AI Assistant","Assets","Users","Settings"];
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const sb = await supabaseServer(); const { data: org } = await sb.from("organizations").select("name").single();
  return (<div className="min-h-screen md:flex">
    <aside className="md:w-60 bg-[#0f1a2e] p-4 md:min-h-screen"><img src="/logo.png" alt="A2Zsoltution" className="rounded mb-1" /><p className="text-xs text-slate-400 mb-4">{org?.name}</p>
      <nav className="flex md:flex-col gap-1 overflow-x-auto">{nav.map(n => <Link key={n} href={`/${n.toLowerCase().replace(/ /g,"-")}`} className="px-3 py-2 rounded hover:bg-white/10 whitespace-nowrap">{n}</Link>)}</nav></aside>
    <main className="flex-1 p-6">{children}</main></div>);
}
