import { revalidatePath } from "next/cache";
import { supabaseServer } from "@/lib/supabase/server";
import { can, audit } from "@/lib/permissions";
import { getAI } from "@/lib/ai/provider";
import { z } from "zod";
const Create = z.object({ subject: z.string().min(3).max(200), description: z.string().max(5000), priority: z.enum(["low","medium","high","critical"]), category: z.string().max(80).optional() });
async function createTicket(fd: FormData) {
  "use server";
  if (!(await can("tickets", "create"))) throw new Error("Forbidden");
  const v = Create.parse(Object.fromEntries(fd)); const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser(); const { data: org } = await sb.rpc("current_org");
  const { data: t, error } = await sb.from("tickets").insert({ ...v, org_id: org, requester_id: user!.id }).select("id").single();
  if (error) throw error; await audit("ticket.create", "ticket", t.id);
  try { // AI suggestion is stored for human review, never auto-applied
    const { data: kb } = await sb.from("kb_articles").select("title,body").eq("published", true).limit(5);
    const a = await getAI().analyzeTicket(v.subject, v.description, (kb ?? []).map(k => `${k.title}: ${k.body}`));
    await sb.from("tickets").update({ ai_summary: a.summary, ai_suggestion: a }).eq("id", t.id);
  } catch {}
  revalidatePath("/tickets");
}
async function setStatus(fd: FormData) {
  "use server";
  if (!(await can("tickets", "update"))) throw new Error("Forbidden");
  const id = String(fd.get("id")), status = z.enum(["open","in_progress","pending","resolved","closed"]).parse(fd.get("status"));
  const sb = await supabaseServer();
  await sb.from("tickets").update({ status, updated_at: new Date().toISOString(), closed_at: status === "closed" ? new Date().toISOString() : null }).eq("id", id);
  await audit("ticket.status", "ticket", id, { status }); revalidatePath("/tickets");
}
export default async function Tickets() {
  const sb = await supabaseServer();
  const { data: tickets } = await sb.from("tickets").select("*").order("created_at", { ascending: false }).limit(100);
  return (<div className="space-y-6 max-w-5xl"><h1 className="text-2xl font-semibold">Tickets</h1>
    {await can("tickets","create") && <form action={createTicket} className="grid gap-2 md:grid-cols-4 bg-[#0f1a2e] p-4 rounded">
      <input name="subject" required placeholder="Subject" className="input md:col-span-2" /><input name="category" placeholder="Category" className="input" />
      <select name="priority" className="input" defaultValue="medium">{["low","medium","high","critical"].map(p => <option key={p}>{p}</option>)}</select>
      <textarea name="description" placeholder="What is happening?" className="input md:col-span-3" /><button className="btn">Create ticket</button></form>}
    {!tickets?.length ? <p className="text-slate-400">No tickets yet. Create the first one above.</p> :
    <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="text-left text-slate-400"><tr><th>#</th><th>Subject</th><th>Priority</th><th>Status</th><th>AI summary</th></tr></thead><tbody>
      {tickets.map(t => <tr key={t.id} className="border-t border-white/10 align-top"><td>{t.number}</td><td>{t.subject}</td><td>{t.priority}</td>
        <td><form action={setStatus} className="flex gap-1"><input type="hidden" name="id" value={t.id} /><select name="status" defaultValue={t.status} className="input">{["open","in_progress","pending","resolved","closed"].map(s => <option key={s}>{s}</option>)}</select><button className="btn">Save</button></form></td>
        <td className="max-w-xs text-slate-300">{t.ai_summary ?? "—"}</td></tr>)}</tbody></table></div>}</div>);
}
