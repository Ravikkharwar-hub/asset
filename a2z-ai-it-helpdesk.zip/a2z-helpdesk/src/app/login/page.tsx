import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";
async function auth(fd: FormData) {
  "use server";
  const sb = await supabaseServer(); const mode = String(fd.get("mode"));
  const email = String(fd.get("email")), password = String(fd.get("password"));
  if (mode === "forgot") { await sb.auth.resetPasswordForEmail(email, { redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/login` }); redirect("/login?msg=Check your email for a reset link"); }
  if (mode === "signup") {
    const { error } = await sb.auth.signUp({ email, password });
    if (error) redirect(`/login?msg=${encodeURIComponent(error.message)}`);
    const { error: e2 } = await sb.rpc("bootstrap_organization", { org_name: String(fd.get("org")), full_name: String(fd.get("name")) });
    if (e2) redirect(`/login?msg=${encodeURIComponent(e2.message)}`);
  } else {
    const { error } = await sb.auth.signInWithPassword({ email, password });
    if (error) redirect(`/login?msg=${encodeURIComponent(error.message)}`);
  }
  redirect("/tickets");
}
export default async function Login({ searchParams }: { searchParams: Promise<{ msg?: string; mode?: string }> }) {
  const { msg, mode = "login" } = await searchParams;
  return (<main className="min-h-screen grid place-items-center p-4"><div className="w-full max-w-sm space-y-5">
    <img src="/logo.png" alt="A2Zsoltution — your complete tech partner" className="rounded-xl" />
    {msg && <p role="status" className="text-sm text-amber-300">{msg}</p>}
    <form action={auth} className="space-y-3"><input type="hidden" name="mode" value={mode} />
      {mode === "signup" && <><input name="org" required placeholder="Organization name" className="input" /><input name="name" required placeholder="Your full name" className="input" /></>}
      <input name="email" type="email" required placeholder="Work email" className="input" />
      {mode !== "forgot" && <input name="password" type="password" required minLength={10} placeholder="Password (10+ characters)" className="input" />}
      <button className="btn w-full">{mode === "signup" ? "Create organization" : mode === "forgot" ? "Send reset link" : "Sign in"}</button></form>
    <p className="text-sm text-slate-400 flex gap-4"><a href="/login">Sign in</a><a href="/login?mode=signup">Create organization</a><a href="/login?mode=forgot">Forgot password</a></p>
  </div></main>);
}
