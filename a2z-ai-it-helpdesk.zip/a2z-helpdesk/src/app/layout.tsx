import "./globals.css";
export const metadata = { title: "A2Zsoltution · AI IT Helpdesk", description: "Your complete tech partner" };
export default function Root({ children }: { children: React.ReactNode }) { return <html lang="en"><body>{children}</body></html>; }
