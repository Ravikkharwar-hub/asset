create extension if not exists pgcrypto;
create table organizations(id uuid primary key default gen_random_uuid(), name text not null, created_at timestamptz default now());
create table profiles(user_id uuid primary key references auth.users on delete cascade, org_id uuid not null references organizations on delete cascade, full_name text, department text, location text, created_at timestamptz default now());
create table roles(id uuid primary key default gen_random_uuid(), org_id uuid references organizations on delete cascade, name text not null, is_system boolean default false, unique(org_id,name));
create table role_permissions(role_id uuid references roles on delete cascade, resource text not null, action text not null, primary key(role_id,resource,action));
create table user_roles(user_id uuid references auth.users on delete cascade, role_id uuid references roles on delete cascade, primary key(user_id,role_id));
create table tickets(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, number bigint generated always as identity, subject text not null, description text, requester_id uuid references auth.users, department text, location text, category text, subcategory text, priority text default 'medium' check(priority in('low','medium','high','critical')), status text default 'open' check(status in('open','in_progress','pending','resolved','closed')), assignee_id uuid references auth.users, sla_due_at timestamptz, asset_id uuid, tags text[] default '{}', resolution text, ai_summary text, ai_suggestion jsonb, ai_reviewed_by uuid references auth.users, created_at timestamptz default now(), updated_at timestamptz default now(), closed_at timestamptz);
create table ticket_comments(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, ticket_id uuid not null references tickets on delete cascade, author_id uuid references auth.users, body text not null, internal boolean default false, created_at timestamptz default now());
create table assets(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, name text not null, type text, serial text, assigned_to uuid references auth.users);
create table kb_articles(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, kind text default 'article' check(kind in('article','faq','guide','sop')), title text not null, body text not null, published boolean default true, created_at timestamptz default now());
create table automation_rules(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, name text not null, condition jsonb not null, action jsonb not null, enabled boolean default true);
create table audit_logs(id bigint generated always as identity primary key, org_id uuid, actor_id uuid, action text not null, entity text, entity_id text, ip text, user_agent text, meta jsonb, created_at timestamptz default now());

create function current_org() returns uuid language sql stable security definer set search_path=public as $$ select org_id from profiles where user_id=auth.uid() $$;
create function has_perm(r text,a text) returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from user_roles ur join role_permissions rp on rp.role_id=ur.role_id where ur.user_id=auth.uid() and rp.resource=r and rp.action in(a,'*')) $$;

do $$ declare t text; begin
 foreach t in array array['tickets','ticket_comments','assets','kb_articles','automation_rules'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy sel on %I for select using(org_id=current_org() and has_perm(%L,%L))',t,t,'read');
  execute format('create policy ins on %I for insert with check(org_id=current_org() and has_perm(%L,%L))',t,t,'create');
  execute format('create policy upd on %I for update using(org_id=current_org() and has_perm(%L,%L))',t,t,'update');
  execute format('create policy del on %I for delete using(org_id=current_org() and has_perm(%L,%L))',t,t,'delete');
 end loop; end $$;
alter table organizations enable row level security; alter table profiles enable row level security; alter table roles enable row level security; alter table role_permissions enable row level security; alter table user_roles enable row level security; alter table audit_logs enable row level security;
create policy org_sel on organizations for select using(id=current_org());
create policy prof_sel on profiles for select using(org_id=current_org());
create policy prof_upd on profiles for update using(user_id=auth.uid());
create policy roles_sel on roles for select using(org_id=current_org());
create policy roles_all on roles for all using(org_id=current_org() and has_perm('roles','manage')) with check(org_id=current_org());
create policy rp_sel on role_permissions for select using(exists(select 1 from roles r where r.id=role_id and r.org_id=current_org()));
create policy rp_all on role_permissions for all using(exists(select 1 from roles r where r.id=role_id and r.org_id=current_org()) and has_perm('roles','manage'));
create policy ur_sel on user_roles for select using(exists(select 1 from profiles p where p.user_id=user_roles.user_id and p.org_id=current_org()));
create policy audit_sel on audit_logs for select using(org_id=current_org() and has_perm('audit','read'));
create policy audit_ins on audit_logs for insert with check(org_id=current_org());

create function bootstrap_organization(org_name text, full_name text) returns uuid language plpgsql security definer set search_path=public as $$
declare o uuid; rid uuid; n text; res text; begin
 if auth.uid() is null or exists(select 1 from profiles where user_id=auth.uid()) then raise exception 'not allowed'; end if;
 insert into organizations(name) values(org_name) returning id into o;
 insert into profiles(user_id,org_id,full_name) values(auth.uid(),o,full_name);
 foreach n in array array['Organization Owner','Organization Admin','IT Manager','IT Agent','Employee','Auditor','Read Only'] loop
  insert into roles(org_id,name,is_system) values(o,n,true) returning id into rid;
  foreach res in array array['tickets','ticket_comments','assets','kb_articles','automation_rules'] loop
   if n in('Organization Owner','Organization Admin') then insert into role_permissions values(rid,res,'*');
   elsif n='IT Manager' then insert into role_permissions select rid,res,a from unnest(array['create','read','update','assign','approve','export']) a;
   elsif n='IT Agent' and res<>'automation_rules' then insert into role_permissions select rid,res,a from unnest(array['create','read','update']) a;
   elsif n='Employee' and res in('tickets','ticket_comments','kb_articles') then insert into role_permissions select rid,res,a from unnest(array['create','read']) a;
   elsif n in('Auditor','Read Only') then insert into role_permissions values(rid,res,'read'); end if;
  end loop;
  if n in('Organization Owner','Organization Admin') then insert into role_permissions values(rid,'roles','manage'),(rid,'users','manage'),(rid,'ai','manage'),(rid,'integrations','manage'),(rid,'audit','read'); end if;
  if n='Auditor' then insert into role_permissions values(rid,'audit','read'); end if;
  if n='Organization Owner' then insert into user_roles values(auth.uid(),rid); end if;
 end loop;
 return o; end $$;
create index on tickets(org_id,status,priority); create index on tickets(org_id,assignee_id); create index on audit_logs(org_id,created_at desc);
